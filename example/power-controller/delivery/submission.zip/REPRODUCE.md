# Reproduce this release

Profile: tinytapeout-ihp-v1
Profile digest: 0bb747d594079d6c104c8407a8fc3c4624d527e6e3b76267959cf11c688b991e
Run: b75f0c2ddd09a00369882772c549e200f01001811bcf8ab1b79019725d53e4b5

Install ChipSim and run the profile's pinned environment setup. Import the companion evidence bundle using the artifact import CLI to inspect original sources, tool identities, logs and checks. Run the captured release target in a restored project with the locked dependencies.

The archive is validated against this pinned Tiny Tapeout profile. Submission and manufacturer acceptance remain external.
